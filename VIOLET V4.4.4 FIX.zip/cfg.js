// Violett Attack 
// script not for sale
// buy script? chat whatsapp
// WhatsApp: 6282231401331

require("./system/module");

//Global Prefix
global.prefa = ["","!",".",",","🎭","〽️"]
global.simbol = "`"

//Settings Owner
global.owner = ["6283189443839"];
global.namaCreator = "Princes Violet";
//Settings Bots
global.nomorbot = ["6283189443839"];
global.namabot = "Violet Defender";

//Settings Thumbnail 
global.imageurl = "https://img100.pixhost.to/images/482/538236748_skyzopedia.jpg";
global.isLink = "https://whatsapp.com/channel/0029VapnGjHDuMRd1EKt563s";

let v = require.resolve(__filename);
fs.watchFile(v, () => {
  fs.unwatchFile(v);
  console.log(chalk.redBright("Update " + __filename));
  delete require.cache[v];
  require(v);
});

